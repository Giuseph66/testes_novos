from flask import Flask, render_template, request, flash, redirect, url_for, send_from_directory
import os
from werkzeug.utils import secure_filename
import uuid
import pdfplumber
import pandas as pd
import re

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta_aqui'

# Configurações
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf'}

# Criar pasta de uploads se não existir
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('Nenhum arquivo selecionado', 'error')
        return redirect(request.url)
    
    file = request.files['file']
    
    if file.filename == '':
        flash('Nenhum arquivo selecionado', 'error')
        return redirect(request.url)
    
    if file and allowed_file(file.filename):
        # Gerar nome único para o arquivo
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4().hex}_{filename}"
        
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(file_path)
        
        flash(f'Arquivo "{filename}" enviado com sucesso!', 'success')
        return redirect(url_for('index'))
    else:
        flash('Tipo de arquivo não permitido. Apenas PDFs são aceitos.', 'error')
        return redirect(request.url)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/list')
def list_files():
    files = []
    if os.path.exists(UPLOAD_FOLDER):
        for filename in os.listdir(UPLOAD_FOLDER):
            if filename.lower().endswith('.pdf'):
                files.append(filename)
    return render_template('list.html', files=files)

@app.route('/view/<filename>')
def view_pdf(filename):
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    tables = []
    
    print(f"\n{'='*50}")
    print(f"PROCESSANDO PDF: {filename}")
    print(f"{'='*50}")
    
    try:
        with pdfplumber.open(file_path) as pdf:
            print(f"Total de páginas no PDF: {len(pdf.pages)}")
            
            for page_num, page in enumerate(pdf.pages):
                print(f"\n--- PÁGINA {page_num + 1} ---")
                
                # Extrair texto da página
                text = page.extract_text()
                if text:
                    print("TEXTO EXTRAÍDO:")
                    print(text)
                    print("-" * 30)
                    
                    # Processar dados estruturados do texto
                    processed_data = process_text_data(text, page_num + 1)
                    if processed_data:
                        tables.extend(processed_data)
                
                # Extrair tabelas da página
                page_tables = page.extract_tables()
                print(f"Tabelas encontradas na página {page_num + 1}: {len(page_tables)}")
                
                if page_tables:
                    for table_num, table in enumerate(page_tables):
                        print(f"\nTABELA {table_num + 1}:")
                        if table and len(table) > 0:
                            for row_num, row in enumerate(table):
                                print(f"Linha {row_num + 1}: {row}")
                            
                            if len(table) > 1:
                                df = pd.DataFrame(table[1:], columns=table[0])
                                tables.append({
                                    'page': page_num + 1,
                                    'table_num': table_num + 1,
                                    'data': df.to_dict('records'),
                                    'columns': df.columns.tolist()
                                })
                                print(f"\nDataFrame criado com {len(df)} linhas e {len(df.columns)} colunas")
                                print("Colunas:", df.columns.tolist())
                                print("Primeiras linhas:")
                                print(df.head())
                        else:
                            print("Tabela vazia ou inválida")
                else:
                    print("Nenhuma tabela encontrada nesta página")
                
                print("-" * 50)
                
    except Exception as e:
        error_msg = f'Erro ao processar o PDF: {str(e)}'
        print(f"ERRO: {error_msg}")
        flash(error_msg, 'error')
        tables = []
    
    print(f"\nTotal de tabelas processadas: {len(tables)}")
    print(f"{'='*50}\n")
    
    # Calcular estatísticas para o template
    total_records = sum(len(table['data']) for table in tables)
    unique_pages = len(set(table['page'] for table in tables))
    
    stats = {
        'total_tables': len(tables),
        'total_records': total_records,
        'unique_pages': unique_pages
    }
    
    return render_template('view_pdf.html', filename=filename, tables=tables, stats=stats)

def process_text_data(text, page_num):
    """Processa dados estruturados do texto extraído"""
    tables = []
    lines = text.split('\n')
    
    # Padrões para identificar dados estruturados
    patterns = {
        'folha_pagamento': {
            'header': ['Ordem', 'Cadastro', 'Nome', 'Situação', 'Pagamento', 'Valor'],
            'data_pattern': r'^(\d{5})\s+(\d+)\s+(.+?)\s+(\d{3})\s+(.+?)\s+(\d{2}/\d{2}/\d{4})\s+([\d.,]+)$'
        },
        'unimed': {
            'header': ['Código', 'Usuário', 'Plano', 'Tipo', 'Idade', 'Inclusão', 'Descrição', 'Valor'],
            'data_pattern': r'^(\d{16})\s+(.+?)\s+(\d+)\s+(.+?)\s+(\d+)\s+(\d{2}/\d{2}/\d{4})\s+(.+?)\s+([\d.,]+)$'
        }
    }
    
    # Tentar identificar o tipo de documento
    if 'Relação Líquidos' in text or 'folha de pagamento' in text.lower():
        print("Identificado como folha de pagamento")
        return process_folha_pagamento(lines, page_num)
    elif 'UNIMED' in text or 'coop. trab. medico' in text.lower():
        print("Identificado como documento UNIMED")
        return process_unimed_document(lines, page_num)
    
    return []

def process_folha_pagamento(lines, page_num):
    """Processa dados de folha de pagamento"""
    tables = []
    current_table = []
    current_section = ""
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Identificar seções
        if any(keyword in line for keyword in ['Diretoria', 'Administrativo', 'Comercial', 'Pós-vendas']):
            if current_table:
                if len(current_table) > 1:
                    tables.append({
                        'page': page_num,
                        'table_num': len(tables) + 1,
                        'section': current_section,
                        'data': current_table,
                        'columns': ['Ordem', 'Cadastro', 'Nome', 'Situação', 'Pagamento', 'Valor']
                    })
            current_section = line
            current_table = []
            continue
            
        # Processar linhas de dados
        if re.match(r'^\d{5}\s+\d+\s+.+?\s+\d{3}\s+.+?\s+\d{2}/\d{2}/\d{4}\s+[\d.,]+$', line):
            parts = line.split()
            if len(parts) >= 7:
                ordem = parts[0]
                cadastro = parts[1]
                # Nome pode ter espaços, então precisamos ser mais cuidadosos
                nome_parts = []
                i = 2
                while i < len(parts) and not parts[i].isdigit():
                    nome_parts.append(parts[i])
                    i += 1
                nome = ' '.join(nome_parts)
                
                if i < len(parts):
                    situacao = parts[i]
                    i += 1
                if i < len(parts):
                    pagamento = parts[i]
                    i += 1
                if i < len(parts):
                    valor = parts[i]
                
                current_table.append({
                    'Ordem': ordem,
                    'Cadastro': cadastro,
                    'Nome': nome,
                    'Situação': situacao,
                    'Pagamento': pagamento,
                    'Valor': valor
                })
    
    # Adicionar última tabela
    if current_table and len(current_table) > 1:
        tables.append({
            'page': page_num,
            'table_num': len(tables) + 1,
            'section': current_section,
            'data': current_table,
            'columns': ['Ordem', 'Cadastro', 'Nome', 'Situação', 'Pagamento', 'Valor']
        })
    
    return tables

def process_unimed_document(lines, page_num):
    """Processa dados de documento UNIMED"""
    tables = []
    current_table = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Processar linhas de dados UNIMED
        if re.match(r'^\d{16}\s+.+?\s+\d+\s+.+?\s+\d+\s+\d{2}/\d{2}/\d{4}\s+.+?\s+[\d.,]+$', line):
            parts = line.split()
            if len(parts) >= 8:
                codigo = parts[0]
                # Nome pode ter espaços
                nome_parts = []
                i = 1
                while i < len(parts) and not parts[i].isdigit():
                    nome_parts.append(parts[i])
                    i += 1
                nome = ' '.join(nome_parts)
                
                if i < len(parts):
                    plano = parts[i]
                    i += 1
                if i < len(parts):
                    tipo = parts[i]
                    i += 1
                if i < len(parts):
                    idade = parts[i]
                    i += 1
                if i < len(parts):
                    inclusao = parts[i]
                    i += 1
                if i < len(parts):
                    descricao = parts[i]
                    i += 1
                if i < len(parts):
                    valor = parts[i]
                
                current_table.append({
                    'Código': codigo,
                    'Usuário': nome,
                    'Plano': plano,
                    'Tipo': tipo,
                    'Idade': idade,
                    'Inclusão': inclusao,
                    'Descrição': descricao,
                    'Valor': valor
                })
    
    if current_table:
        tables.append({
            'page': page_num,
            'table_num': 1,
            'section': 'Dados UNIMED',
            'data': current_table,
            'columns': ['Código', 'Usuário', 'Plano', 'Tipo', 'Idade', 'Inclusão', 'Descrição', 'Valor']
        })
    
    return tables

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000) 