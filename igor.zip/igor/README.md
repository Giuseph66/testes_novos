# Aplicação Flask para Upload e Visualização de PDFs

Esta aplicação permite fazer upload de arquivos PDF e extrair tabelas deles para visualização.

## Instalação

1. Instale as dependências:
```bash
pip install -r requirements.txt
```

2. Execute a aplicação:
```bash
python app.py
```

3. Acesse no navegador:
```
http://localhost:5000
```

## Funcionalidades

- **Upload de PDFs**: Interface moderna para enviar arquivos PDF
- **Listagem de arquivos**: Visualize todos os PDFs enviados
- **Extração de tabelas**: Extrai automaticamente tabelas dos PDFs usando pdfplumber
- **Visualização em tabelas**: Exibe os dados em tabelas responsivas e organizadas
- **Download**: Permite baixar os PDFs originais

## Estrutura do Projeto

```
├── app.py              # Aplicação principal Flask
├── requirements.txt    # Dependências Python
├── templates/          # Templates HTML
│   ├── index.html     # Página de upload
│   ├── list.html      # Lista de arquivos
│   └── view_pdf.html  # Visualização de tabelas
└── uploads/           # Pasta onde os PDFs são salvos
```

## Tecnologias Utilizadas

- **Flask**: Framework web
- **pdfplumber**: Extração de tabelas de PDFs
- **pandas**: Manipulação de dados
- **Bootstrap**: Interface responsiva 